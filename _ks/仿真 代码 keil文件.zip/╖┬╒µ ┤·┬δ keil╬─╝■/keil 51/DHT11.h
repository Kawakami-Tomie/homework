#ifndef __DHT11_H__
#define __DHT11_H__
 
void DHT11_Init(void);
void DHT11_receive(void);

#endif