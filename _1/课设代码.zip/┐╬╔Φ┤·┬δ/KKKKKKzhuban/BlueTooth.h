#ifndef __BLUETOOTH_H__
#define __BLUETOOTH_H__


void UART_Init(void);
void UART_SendByte(unsigned char dat);

#endif
