#ifndef __KEY_H__
#define __KEY_H__

void Delay(unsigned int xms);
unsigned char Key();

#endif
